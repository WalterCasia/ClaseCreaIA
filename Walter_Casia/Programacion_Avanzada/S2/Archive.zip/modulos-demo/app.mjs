import {suma, resta} from './math.mjs';

const resultadoSuma = suma(5, 3);
const resultadoResta = resta(5, 3);

console.log(`La suma de 5 y 3 es: ${resultadoSuma}`);
console.log(`La resta de 5 y 3 es: ${resultadoResta}`);